% Double-click the .bat file to run the program.
% You can replace the target image path by renaming the .bat file to .txt.

% If you use this implementation please cite:
% Zhongli Fan et al.: "Nonlinear Intensity, Scale and Rotation Invariant Matching for Multimodal Images"
% IEEE TPAMI

% ----------------------------------------------------------------------
% Permission to use, copy, or modify this software and its documentation
% for educational and research purposes only and without fee is here
% granted, provided that this copyright notice and the original authors'
% names appear on all copies and supporting documentation. This program
% shall not be used, rewritten, or adapted as the basis of a commercial
% software or hardware product without first obtaining permission of the
% authors. The authors make no representations about the suitability of
% this software for any purpose. It is provided "as is" without express
% or implied warranty.
%----------------------------------------------------------------------

%
% Contact: fanzhongli@whu.edu.cn